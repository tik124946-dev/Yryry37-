#include "router.hpp"
#include "util.hpp"
#include "zipx.hpp"
#include <errno.h>
#include <string.h>
#include <algorithm>

static std::vector<std::string> split(const std::string& p) {
    std::vector<std::string> v; std::string c;
    for (char ch : p) { if (ch == '/') { if (!c.empty()) v.push_back(c); c.clear(); } else c += ch; }
    if (!c.empty()) v.push_back(c);
    return v;
}

static bool is_marker(const std::string& c) {
    std::string l = lower(c);
    return l == "switch" || l == "atmosphere" || l == "config" || l == "bootloader";
}

static std::string stem_of(const std::string& n) {
    size_t d = n.rfind('.');
    return d == std::string::npos || d == 0 ? n : n.substr(0, d);
}

std::string route_dest(const std::string& root, const std::string& tname, bool multi, const std::string& rel,
                       bool has_nro, bool* is_switch) {
    if (is_switch) *is_switch = false;
    auto comps = split(rel);
    if (comps.empty()) return root + "archive_nintendo/downloads/" + tname + "/unnamed";
    // структура SD-карты уже есть в торренте: switch/…, atmosphere/…, config/…, bootloader/…
    for (size_t i = 0; i < comps.size() && i < 2; i++) {
        if (is_marker(comps[i]) && i + 1 < comps.size()) {
            std::string d = root;
            for (size_t k = i; k < comps.size(); k++) { d += (k == i ? lower(comps[k]) : comps[k]); if (k + 1 < comps.size()) d += "/"; }
            if (is_switch) *is_switch = true;
            return d;
        }
    }
    if (has_nro) {
        if (is_switch) *is_switch = true;
        if (!multi) return root + "switch/" + stem_of(comps[0]) + "/" + comps[0];
        return root + "switch/" + tname + "/" + rel;
    }
    return root + "archive_nintendo/downloads/" + tname + "/" + (multi ? rel : comps.back());
}

static bool torrent_has_nro(const Meta& m) {
    for (auto& f : m.files) if (ends_with_ci(f.path, ".nro")) return true;
    return false;
}

std::string route_label(const Meta& m, size_t idx, bool install_nsp) {
    const TFile& f = m.files[idx];
    if (f.pad) return "пропуск";
    if (install_nsp && ends_with_ci(f.path, ".nsp")) return "установка NSP";
    bool sw = false;
    std::string d = route_dest("", m.name, m.multi, f.path, torrent_has_nro(m), &sw);
    size_t sl = d.find('/');
    std::string top = sl == std::string::npos ? d : d.substr(0, sl);
    if (sw) return top + "/ (на SD)";
    return "archive_nintendo/downloads";
}

bool Router::file_begin(const Meta& m, size_t idx) {
    const TFile& f = m.files[idx];
    cur_name_ = f.path;
    wrote_ = 0;
    if (install_ && ends_with_ci(f.path, ".nsp")) {
        inst_ = pf_->new_installer(storage_);
        if (!inst_) { err_ = "установщик недоступен"; return false; }
        inst_bytes_ = 0; inst_total_ = f.len;
        return true;
    }
    bool sw = false;
    std::string dest = route_dest(pf_->root(), m.name, m.multi, f.path, torrent_has_nro(m), &sw);
    cur_dest_ = dest; cur_switch_ = sw;
    size_t sl = dest.rfind('/');
    if (sl != std::string::npos && !mkdirs(dest.substr(0, sl))) { err_ = "не удалось создать папку для " + dest; return false; }
    fp_ = fopen(dest.c_str(), "wb");
    if (!fp_) { err_ = "не удалось создать файл " + dest; return false; }
    static char buf[1 << 16];
    setvbuf(fp_, buf, _IOFBF, sizeof buf);
    return true;
}

bool Router::file_data(const uint8_t* p, size_t n) {
    if (inst_) {
        if (!inst_->write(p, n)) { err_ = inst_->error(); return false; }
        inst_bytes_ += n;
        return true;
    }
    if (!fp_) { err_ = "файл не открыт"; return false; }
    if (fwrite(p, 1, n, fp_) != n) {
        int e = errno;
        if (wrote_ + n >= 0xFFFF0000ull && (e == EFBIG || e == 0 || e == ENOSPC))
            err_ = "файл больше 4 ГБ не записывается на SD с FAT32. Отформатируйте карту в exFAT";
        else if (e == ENOSPC) err_ = "на карте закончилось место";
        else err_ = "ошибка записи на SD (" + std::string(strerror(e)) + ")";
        return false;
    }
    wrote_ += n;
    return true;
}

bool Router::file_end() {
    if (inst_) {
        bool ok = inst_->finish();
        if (!ok) err_ = inst_->error();
        else { last_info_ = inst_->info(); n_installed_++; }
        delete inst_; inst_ = nullptr;
        return ok;
    }
    if (fp_) {
        bool ok = fclose(fp_) == 0; fp_ = nullptr;
        if (!ok) { err_ = "ошибка записи на SD при закрытии файла"; return false; }
        if (cur_switch_) n_routed_++;
        else if (ends_with_ci(cur_dest_, ".zip")) {
            // zip с портами/хомбрю: раскладываем по папкам и удаляем архив
            std::string stem = cur_name_.substr(cur_name_.rfind('/') == std::string::npos ? 0 : cur_name_.rfind('/') + 1);
            stem = stem.substr(0, stem.rfind('.'));
            int n = 0; std::string e;
            if (extract_zip(cur_dest_, pf_->root(), stem, n, e)) { remove(cur_dest_.c_str()); n_routed_ += n; n_zips_++; }
            else { n_plain_++; zip_err_ = "zip не распакован (" + e + ")"; }
        } else n_plain_++;
    }
    return true;
}

void Router::abort() {
    if (fp_) { fclose(fp_); fp_ = nullptr; }
    if (inst_) { inst_->abort(); delete inst_; inst_ = nullptr; }
}

std::string Router::summary() const {
    std::string s;
    if (n_installed_) s += "установлено NSP: " + std::to_string(n_installed_);
    if (n_routed_) { if (!s.empty()) s += ", "; s += "разложено файлов на SD: " + std::to_string(n_routed_); }
    if (n_plain_) { if (!s.empty()) s += ", "; s += "сохранено: " + std::to_string(n_plain_); }
    if (n_zips_) { if (!s.empty()) s += ", "; s += "распаковано zip: " + std::to_string(n_zips_); }
    if (!zip_err_.empty()) { if (!s.empty()) s += "; "; s += zip_err_; }
    return s;
}
