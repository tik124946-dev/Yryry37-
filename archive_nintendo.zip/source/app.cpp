#include "app.hpp"
#include "util.hpp"
#include <algorithm>
#include <stdio.h>
#include <string.h>

static const uint32_t BG = C(15, 17, 23), PANEL = C(23, 26, 35), CARD = C(31, 35, 48), CARD2 = C(40, 45, 62);
static const uint32_t ACC = C(79, 195, 247), OKC = C(102, 214, 138), WARN = C(255, 193, 7), ERRC = C(239, 83, 80);
static const uint32_t TXT = C(232, 234, 240), DIM = C(136, 143, 160), BAR_BG = C(52, 58, 78);
static const int TOP_H = 64, SIDE_W = 248, BOT_H = 46, CX = SIDE_W + 18;
static const uint64_t MEM_CAP = 32ull << 20;
static const char* TAB_NAMES[3] = {"Установленные", "Загрузки", "Торренты"};

App::App(Platform* pf) : pf_(pf) {}
App::~App() {
    for (auto& j : jobs_) { j->swarm.reset(); if (j->router) j->router->abort(); }
    if (awake_) pf_->keep_awake(false);
    if (screen_off_) pf_->backlight(true);
}

bool App::job_running() const { return running() != nullptr; }

App::Job* App::running() const {
    for (auto& j : jobs_) if (j->st == Job::RUNNING) return j.get();
    return nullptr;
}
App::Job* App::find_job(const std::string& h) const {
    for (auto& j : jobs_) if (j->hash == h) return j.get();
    return nullptr;
}

std::string App::job_state_text() const {
    Job* j = running();
    return j ? "running" : "idle";
}

void App::init() {
    std::string root = pf_->root();
    mkdirs(root + "archive_nintendo/torrents");
    mkdirs(root + "archive_nintendo/downloads");
    lib_.load(root + "archive_nintendo/library.txt");
    install_nsp_ = pf_->can_install();
    // незавершённые загрузки возвращаем в список как «приостановленные»
    for (auto& e : lib_.items) {
        if (e.status == 1 || e.tpath.empty()) continue;
        auto j = std::make_unique<Job>();
        j->tpath = e.tpath; j->hash = e.hash; j->files_done = e.files_done;
        std::string err;
        if (!Meta::load(e.tpath, j->meta, err)) { j->st = Job::ERROR; j->err = ".torrent: " + err; j->meta.name = e.name; }
        else j->st = Job::PAUSED;
        if (e.status == 2 && j->st == Job::PAUSED) { j->st = Job::ERROR; j->err = e.note; }
        jobs_.push_back(std::move(j));
    }
    scan_torrents();
    tab_ = jobs_.empty() ? 2 : 1;
    last_space_ = 0;
}

void App::scan_torrents() {
    tors_.clear();
    std::string root = pf_->root();
    std::vector<std::string> dirs = {tdir(), root + "torrents", root};
    for (auto& d : dirs) {
        std::vector<std::string> names;
        if (!list_dir(d, names)) continue;
        std::sort(names.begin(), names.end());
        for (auto& n : names) {
            if (!ends_with_ci(n, ".torrent") || tors_.size() >= 300) continue;
            TorEntry t; t.path = (d.back() == '/' ? d : d + "/") + n; t.fname = n;
            Meta m; std::string err;
            if (Meta::load(t.path, m, err)) {
                t.ok = true; t.name = m.name; t.total = m.total; t.nfiles = m.files.size(); t.ntr = m.trackers.size();
                t.hash = to_hex(m.infohash, 20);
            } else { t.err = err; t.name = n; }
            bool dup = false;
            for (auto& o : tors_) if (o.ok && o.hash == t.hash) dup = true;
            if (!dup) tors_.push_back(t);
        }
    }
    preview_idx_ = -1;
    if (sel_[2] >= (int)tors_.size()) sel_[2] = std::max(0, (int)tors_.size() - 1);
    dirty_ = true;
}

bool App::confirm(const std::string& key, uint64_t now) {
    if (confirm_key_ == key && now < confirm_until_) { confirm_key_.clear(); return true; }
    confirm_key_ = key; confirm_until_ = now + 4000;
    return false;
}

// ───────── место на карте ─────────
bool App::space_check(const Meta& m, size_t from, std::string& err) {
    uint64_t sd_need = 0, nand_need = 0;
    for (size_t i = from; i < m.files.size(); i++) {
        const TFile& f = m.files[i];
        if (f.pad) continue;
        if (install_nsp_ && ends_with_ci(f.path, ".nsp")) { (storage_ == 0 ? sd_need : nand_need) += f.len; }
        else sd_need += f.len;
    }
    const uint64_t margin = 64ull << 20;
    int64_t sd = pf_->free_space(0), nand = pf_->free_space(1);
    if (sd >= 0 && sd_need && (uint64_t)sd < sd_need + margin) {
        err = "не хватает места на SD: нужно " + human_size((double)sd_need) + ", свободно " + human_size((double)sd);
        return false;
    }
    if (nand >= 0 && nand_need && (uint64_t)nand < nand_need + margin) {
        err = "не хватает места в памяти консоли: нужно " + human_size((double)nand_need) + ", свободно " + human_size((double)nand);
        return false;
    }
    return true;
}

// ───────── задачи ─────────
void App::save_job(Job& j, int status) {
    LibEntry e;
    if (LibEntry* x = lib_.find(j.hash)) e = *x;
    e.hash = j.hash; e.name = j.meta.name; e.total = j.meta.total;
    e.files_done = (uint32_t)j.files_done; e.files_total = (uint32_t)j.meta.files.size();
    e.status = status; e.when = pf_->epoch();
    e.note = status == 2 ? j.err : j.note;
    e.tpath = j.tpath;
    lib_.upsert(e);
    lib_.save();
}

void App::add_job(const TorEntry& t, uint64_t now) {
    if (!t.ok) { toast("Ошибка .torrent: " + t.err, now); return; }
    if (Job* ex = find_job(t.hash)) {
        (void)ex; tab_ = 1; toast("Уже в загрузках", now); return;
    }
    LibEntry* le = lib_.find(t.hash);
    if (le && le->status == 1 && !confirm("re:" + t.hash, now)) {
        toast("Это уже скачано. Нажмите A ещё раз, чтобы скачать заново", now); return;
    }
    auto j = std::make_unique<Job>();
    std::string err;
    if (!Meta::load(t.path, j->meta, err)) { toast("Ошибка .torrent: " + err, now); return; }
    j->tpath = t.path; j->hash = t.hash; j->files_done = 0; j->st = Job::QUEUED;
    jobs_.push_back(std::move(j));
    save_job(*jobs_.back(), 0);
    toast(running() ? "Добавлено в очередь" : "Запускаю…", now);
    queue_next(now);
    tab_ = 1;
    sel_[1] = 0;
}

void App::start_job(Job& j, uint64_t now) {
    j.err.clear();
    if (j.files_done >= j.meta.files.size()) { j.st = Job::DONE; return; }
    std::string err;
    if (!space_check(j.meta, j.files_done, err)) {
        j.st = Job::ERROR; j.err = err; save_job(j, 2); return;
    }
    bool inst = install_nsp_ && pf_->can_install();
    j.router = std::make_unique<Router>(pf_, inst, storage_);
    j.swarm = std::make_unique<Swarm>(j.meta, j.router.get(), j.files_done, MEM_CAP);
    Job* jp = &j;
    j.swarm->set_file_done_cb([this, jp](size_t i) { jp->files_done = i + 1; save_job(*jp, 0); });
    j.st = Job::RUNNING;
    t_stall_start_ = now;
    dirty_ = true;
}

void App::stop_job(Job& j) {
    j.swarm.reset();
    if (j.router) { j.router->abort(); j.note = j.router->summary(); j.router.reset(); }
}

void App::finish_job(Job& j, uint64_t now) {
    j.note = j.router->summary();
    if (j.router->last_info().size()) j.note += (j.note.empty() ? "" : "; ") + std::string("ID ") + j.router->last_info();
    j.swarm.reset(); j.router.reset();
    j.st = Job::DONE;
    j.files_done = j.meta.files.size();
    save_job(j, 1);
    toast("Готово: " + j.meta.name, now, 8000);
}

void App::queue_next(uint64_t now) {
    if (running()) return;
    for (auto& j : jobs_) if (j->st == Job::QUEUED) { start_job(*j, now); if (j->st == Job::RUNNING) return; }
}

void App::update_awake() {
    bool want = running() != nullptr;
    if (want != awake_) { awake_ = want; pf_->keep_awake(want); }
}

// ───────── ввод ─────────
std::vector<App::Job*> App::dl_jobs() const {
    std::vector<Job*> v;
    for (auto& j : jobs_) if (j->st != Job::DONE) v.push_back(j.get());
    std::stable_sort(v.begin(), v.end(), [](Job* a, Job* b) { return (a->st == Job::RUNNING) > (b->st == Job::RUNNING); });
    return v;
}

std::vector<LibEntry*> App::done_entries() {
    std::vector<LibEntry*> v;
    for (auto& e : lib_.items) if (e.status == 1) v.push_back(&e);
    std::reverse(v.begin(), v.end());
    return v;
}

int App::list_len() const {
    if (tab_ == 2) return (int)tors_.size();
    if (tab_ == 1) return (int)dl_jobs().size();
    int n = 0; for (auto& e : lib_.items) if (e.status == 1) n++;
    return n;
}

void App::on_a(uint64_t now) {
    if (tab_ == 2) {
        if (tors_.empty()) return;
        add_job(tors_[sel_[2]], now);
    } else if (tab_ == 1) {
        auto v = dl_jobs();
        if (v.empty()) return;
        Job* j = v[std::min<int>(sel_[1], (int)v.size() - 1)];
        if (j->st == Job::RUNNING) { stop_job(*j); j->st = Job::PAUSED; save_job(*j, 0); toast("Пауза", now); queue_next(now); }
        else if (j->st == Job::PAUSED || j->st == Job::ERROR) {
            j->st = Job::QUEUED;
            if (Job* r = running()) { (void)r; toast("В очереди", now); }
            else queue_next(now);
        }
    }
}

void App::on_x(uint64_t now) {
    if (tab_ == 2) { scan_torrents(); toast("Список торрентов обновлён: " + std::to_string(tors_.size()), now); return; }
    if (tab_ == 1) {
        auto v = dl_jobs();
        if (v.empty()) return;
        Job* j = v[std::min<int>(sel_[1], (int)v.size() - 1)];
        if (!confirm("cancel:" + j->hash, now)) { toast("Нажмите X ещё раз — отменить и убрать из списка", now); return; }
        std::string h = j->hash;
        stop_job(*j);
        lib_.remove(h); lib_.save();
        jobs_.erase(std::remove_if(jobs_.begin(), jobs_.end(), [&](const std::unique_ptr<Job>& p) { return p->hash == h; }), jobs_.end());
        toast("Убрано из загрузок", now);
        queue_next(now);
    } else {
        auto v = done_entries();
        if (v.empty()) return;
        LibEntry* e = v[std::min<int>(sel_[0], (int)v.size() - 1)];
        if (!confirm("del:" + e->hash, now)) { toast("Нажмите X ещё раз — убрать запись из списка (файлы и игры не удаляются)", now); return; }
        std::string h = e->hash;
        lib_.remove(h); lib_.save();
        jobs_.erase(std::remove_if(jobs_.begin(), jobs_.end(), [&](const std::unique_ptr<Job>& p) { return p->hash == h; }), jobs_.end());
        toast("Запись убрана", now);
    }
}

void App::handle_keys(uint32_t k, uint64_t now) {
    if (k & (K_L | K_ZL | K_LEFT)) { tab_ = (tab_ + 2) % 3; dirty_ = true; }
    if (k & (K_R | K_ZR | K_RIGHT)) { tab_ = (tab_ + 1) % 3; dirty_ = true; }
    int n = list_len();
    if (k & K_UP) { sel_[tab_] = std::max(0, sel_[tab_] - 1); dirty_ = true; }
    if (k & K_DOWN) { sel_[tab_] = std::min(std::max(0, n - 1), sel_[tab_] + 1); dirty_ = true; }
    if (k & K_A) on_a(now);
    if (k & K_X) on_x(now);
    if (k & K_Y) {
        if (!pf_->can_install()) toast("Установка NSP недоступна (нет прав ncm/ns/es). Запустите через hbmenu в режиме титула", now, 6000);
        else { install_nsp_ = !install_nsp_; toast(install_nsp_ ? "NSP будут устанавливаться" : "NSP будут только сохраняться как файлы", now); }
    }
    if (k & K_MINUS) {
        if (running()) toast("Менять место установки можно между загрузками", now);
        else if (!pf_->can_install()) toast("Установка NSP недоступна", now);
        else { storage_ = storage_ ? 0 : 1; toast(storage_ ? "NSP устанавливаются в память консоли" : "NSP устанавливаются на SD-карту", now); }
    }
    if (k & K_PLUS) {
        if (!running() || confirm("exit", now)) exit_ = true;
        else toast("Идёт загрузка. Нажмите + ещё раз для выхода (прогресс сохранится)", now, 4000);
    }
}

bool App::frame(uint32_t keys, uint64_t now) {
    // экран выключен: любая кнопка только будит экран и не нажимает ничего другого
    if (screen_off_) {
        if (keys) { screen_off_ = false; pf_->backlight(true); t_stall_start_ = now; dirty_ = true; keys = 0; }
    }
    if (keys) handle_keys(keys, now);

    if (Job* j = running()) {
        j->swarm->tick(now);
        if (j->swarm->failed()) {
            j->err = j->swarm->error();
            std::string e = j->err;
            stop_job(*j);
            j->st = Job::ERROR; j->err = e;
            save_job(*j, 2);
            toast("Ошибка: " + e, now, 10000);
            queue_next(now);
        } else if (j->swarm->finished()) {
            finish_job(*j, now);
            queue_next(now);
        }
    }
    update_awake();

    // нет прогресса stall_limit_ms → гасим экран (консоль не засыпает, загрузка продолжается)
    if (Job* j = running()) {
        uint64_t last = std::max(j->swarm->last_progress(), t_stall_start_);
        if (!screen_off_ && now > last && now - last >= stall_limit_ms) {
            screen_off_ = true; pf_->backlight(false);
        }
    }
    if (now - last_space_ > 2500) {
        last_space_ = now;
        sd_free_ = pf_->free_space(0); sd_total_ = pf_->total_space(0);
        dirty_ = true;
    }
    return !exit_;
}

// ───────── отрисовка ─────────
static std::string pct(uint64_t a, uint64_t b) {
    char s[16]; snprintf(s, sizeof s, "%.1f%%", b ? 100.0 * (double)a / (double)b : 0.0);
    return s;
}

static void bar(Gfx& g, int x, int y, int w, int h, double frac, uint32_t col) {
    frac = std::max(0.0, std::min(1.0, frac));
    g.rrect(x, y, w, h, h / 2, BAR_BG);
    int fw = (int)(w * frac);
    if (fw > 0) g.rrect(x, y, std::max(fw, h), h, h / 2, col);
}

void App::draw_top(Gfx& g) {
    g.rect(0, 0, Gfx::W, TOP_H, PANEL);
    g.text(20, 14, "archive_nintendo", TXT, F_TITLE);
    std::string t = pf_->time_str();
    g.text_right(Gfx::W - 22, 10, t, TXT, F_BIG);
    // свободное место на SD
    int x = 420, w = 520;
    std::string s;
    if (sd_free_ >= 0 && sd_total_ > 0) s = "SD-карта: свободно " + human_size((double)sd_free_) + " из " + human_size((double)sd_total_);
    else s = "SD-карта: нет данных";
    g.text(x, 8, s, TXT, F_BODY);
    double used = sd_total_ > 0 && sd_free_ >= 0 ? 1.0 - (double)sd_free_ / (double)sd_total_ : 0;
    bar(g, x, 40, w, 10, used, used > 0.92 ? ERRC : used > 0.8 ? WARN : ACC);
}

void App::draw_side(Gfx& g) {
    g.rect(0, TOP_H, SIDE_W, Gfx::H - TOP_H, PANEL);
    int cnt[3];
    cnt[0] = 0; for (auto& e : lib_.items) if (e.status == 1) cnt[0]++;
    cnt[1] = (int)dl_jobs().size();
    cnt[2] = (int)tors_.size();
    for (int i = 0; i < 3; i++) {
        int y = TOP_H + 16 + i * 66;
        bool a = tab_ == i;
        if (a) { g.rrect(10, y, SIDE_W - 20, 56, 10, CARD2); g.rect(10, y + 8, 5, 40, ACC); }
        g.text(30, y + 14, TAB_NAMES[i], a ? TXT : DIM, F_BODY);
        if (cnt[i]) {
            std::string c = std::to_string(cnt[i]);
            int cw = g.text_width(c, F_SMALL) + 14;
            g.rrect(SIDE_W - 22 - cw, y + 17, cw, 22, 11, i == 1 && running() ? ACC : BAR_BG);
            g.text_center(SIDE_W - 22 - cw / 2, y + 19, c, a || (i == 1 && running()) ? C(10, 12, 18) : TXT, F_SMALL);
        }
    }
    int y = Gfx::H - BOT_H - 120;
    g.text(20, y, "Установка NSP:", DIM, F_SMALL);
    bool can = pf_->can_install();
    g.text(20, y + 20, !can ? "недоступна" : install_nsp_ ? "✓ включена" : "выключена", !can ? ERRC : install_nsp_ ? OKC : WARN, F_BODY);
    g.text(20, y + 54, "Куда ставить:", DIM, F_SMALL);
    g.text(20, y + 74, storage_ ? "память консоли" : "SD-карта", TXT, F_BODY);
}

static int rows_visible(int h, int rh) { return std::max(1, h / rh); }

void App::draw_torrents(Gfx& g, uint64_t now) {
    (void)now;
    int x = CX, y = TOP_H + 14, w = Gfx::W - x - 16;
    g.text(x, y, "Торренты: " + std::to_string(tors_.size()) + "   ·   папка sdmc:/archive_nintendo/torrents", DIM, F_SMALL);
    y += 28;
    if (tors_.empty()) {
        g.rrect(x, y + 10, w, 170, 12, CARD);
        g.text(x + 24, y + 30, "Здесь пока пусто", TXT, F_TITLE);
        g.text(x + 24, y + 70, "Положите файлы .torrent в папку", DIM, F_BODY);
        g.text(x + 24, y + 98, "sdmc:/archive_nintendo/torrents/", ACC, F_BODY);
        g.text(x + 24, y + 126, "и нажмите X (обновить список).", DIM, F_BODY);
        return;
    }
    int lw = 600, rh = 58;
    int avail = Gfx::H - BOT_H - y - 8;
    int vis = rows_visible(avail, rh);
    int sel = sel_[2];
    int first = std::max(0, std::min(sel - vis / 2, (int)tors_.size() - vis));
    for (int i = 0; i < vis && first + i < (int)tors_.size(); i++) {
        const TorEntry& t = tors_[first + i];
        int yy = y + i * rh;
        bool a = first + i == sel;
        g.rrect(x, yy, lw, rh - 6, 10, a ? CARD2 : CARD);
        if (a) g.frame(x, yy, lw, rh - 6, 2, ACC);
        g.text(x + 14, yy + 5, g.fit(t.ok ? t.name : t.fname, lw - 28, F_BODY), t.ok ? TXT : ERRC, F_BODY);
        std::string sub;
        if (t.ok) sub = human_size((double)t.total) + "  ·  файлов: " + std::to_string(t.nfiles);
        else sub = t.err;
        Job* j = t.ok ? find_job(t.hash) : nullptr;
        LibEntry* le = t.ok ? lib_.find(t.hash) : nullptr;
        std::string tag; uint32_t tc = DIM;
        if (j && j->st != Job::DONE) { tag = "в загрузках"; tc = ACC; }
        else if (le && le->status == 1) { tag = "✓ скачано"; tc = OKC; }
        g.text(x + 14, yy + 31, g.fit(sub, lw - 200, F_SMALL), DIM, F_SMALL);
        if (!tag.empty()) g.text_right(x + lw - 14, yy + 31, tag, tc, F_SMALL);
    }
    // предпросмотр выбранного
    const TorEntry& t = tors_[sel];
    int px = x + lw + 16, pw = w - lw - 16;
    g.rrect(px, y, pw, Gfx::H - BOT_H - y - 8, 12, CARD);
    if (!t.ok) { g.text(px + 16, y + 14, "Файл повреждён", ERRC, F_BODY); return; }
    if (preview_idx_ != sel) {
        std::string e; preview_idx_ = sel;
        if (!Meta::load(t.path, preview_, e)) preview_.files.clear();
    }
    g.text(px + 16, y + 12, g.fit(t.name, pw - 32, F_BODY), TXT, F_BODY);
    char b[160];
    snprintf(b, sizeof b, "%s · кусок %s · трекеров: %d", human_size((double)preview_.total).c_str(), human_size((double)preview_.plen).c_str(), (int)preview_.trackers.size());
    g.text(px + 16, y + 42, g.fit(b, pw - 32, F_SMALL), DIM, F_SMALL);
    int fy = y + 72;
    g.text(px + 16, fy, "Куда пойдут файлы:", DIM, F_SMALL);
    fy += 24;
    bool inst = install_nsp_ && pf_->can_install();
    int maxrows = (Gfx::H - BOT_H - 20 - fy) / 40;
    for (size_t i = 0; i < preview_.files.size() && (int)i < maxrows; i++) {
        if (preview_.files[i].pad) continue;
        g.text(px + 16, fy, g.fit(preview_.files[i].path, pw - 32, F_SMALL), TXT, F_SMALL);
        g.text(px + 16, fy + 17, "→ " + route_label(preview_, i, inst) + "   " + human_size((double)preview_.files[i].len), ACC, F_SMALL);
        fy += 40;
    }
    if ((int)preview_.files.size() > maxrows) g.text(px + 16, fy, "… и ещё " + std::to_string(preview_.files.size() - maxrows), DIM, F_SMALL);
}

void App::draw_card(Gfx& g, Job& j, int x, int y, int w, uint64_t now) {
    Swarm* s = j.swarm.get();
    Router* r = j.router.get();
    g.rrect(x, y, w, 236, 14, CARD);
    g.text(x + 18, y + 12, g.fit(j.meta.name, w - 36, F_TITLE), TXT, F_TITLE);
    uint64_t total = j.meta.total;
    uint64_t dl = s->downloaded_abs(), cons = s->consumed_bytes();
    double sp = s->speed();
    std::string line;
    if (r->installing()) line = "Установка NSP: " + j.meta.files[std::min(s->cur_file(), j.meta.files.size() - 1)].path;
    else line = "Файл " + std::to_string(std::min(s->cur_file() + 1, j.meta.files.size())) + " из " + std::to_string(j.meta.files.size()) + ": " + r->current_name();
    g.text(x + 18, y + 50, g.fit(line, w - 36, F_SMALL), DIM, F_SMALL);
    int bw = w - 36;
    // скачано
    g.text(x + 18, y + 76, "Скачано", TXT, F_SMALL);
    g.text_right(x + w - 18, y + 76, human_size((double)dl) + " / " + human_size((double)total) + "   " + pct(dl, total), TXT, F_SMALL);
    bar(g, x + 18, y + 98, bw, 14, total ? (double)dl / (double)total : 0, ACC);
    // установлено / записано
    bool nsp = r->installing() || r->n_installed() > 0;
    g.text(x + 18, y + 120, nsp ? "Установлено / записано" : "Записано на SD", TXT, F_SMALL);
    g.text_right(x + w - 18, y + 120, human_size((double)cons) + "   " + pct(cons, total), TXT, F_SMALL);
    bar(g, x + 18, y + 142, bw, 14, total ? (double)cons / (double)total : 0, OKC);
    // скорость / ETA
    int64_t eta = sp > 1024 ? (int64_t)((double)(total - std::min(total, dl)) / sp) : -1;
    g.text(x + 18, y + 168, "Скорость", DIM, F_SMALL);
    g.text(x + 18, y + 186, human_speed(sp), TXT, F_BODY);
    g.text(x + 230, y + 168, "Осталось", DIM, F_SMALL);
    g.text(x + 230, y + 186, eta >= 0 ? human_time(eta) : "—", TXT, F_BODY);
    g.text(x + 420, y + 168, "Буфер в памяти", DIM, F_SMALL);
    g.text(x + 420, y + 186, human_size((double)s->buffered_bytes()), TXT, F_BODY);
    g.text(x + 640, y + 168, "Источник", DIM, F_SMALL);
    g.text(x + 640, y + 186, g.fit(s->status_text(), w - 660, F_BODY), TXT, F_BODY);
    // предупреждение о простое
    uint64_t last = std::max(s->last_progress(), t_stall_start_);
    if (now > last && now - last > 20000) {
        uint64_t idle = now - last;
        int64_t left = (int64_t)(stall_limit_ms > idle ? (stall_limit_ms - idle) / 1000 : 0);
        char b[160];
        snprintf(b, sizeof b, "Нет данных уже %s · экран погаснет через %s (любая кнопка включит)", human_time((int64_t)(idle / 1000)).c_str(), human_time(left).c_str());
        g.text(x + 18, y + 212, g.fit(b, w - 36, F_SMALL), WARN, F_SMALL);
    } else {
        g.text(x + 18, y + 212, "Экран не гаснет, пока идёт загрузка. Данные не копятся на SD — установленное сразу освобождается.", DIM, F_SMALL);
    }
}

void App::draw_downloads(Gfx& g, uint64_t now) {
    int x = CX, y = TOP_H + 14, w = Gfx::W - x - 16;
    auto v = dl_jobs();
    if (v.empty()) {
        g.rrect(x, y, w, 120, 12, CARD);
        g.text(x + 24, y + 22, "Нет активных загрузок", TXT, F_TITLE);
        g.text(x + 24, y + 62, "Откройте вкладку «Торренты» и нажмите A на выбранном торренте.", DIM, F_BODY);
        return;
    }
    int sel = std::min(sel_[1], (int)v.size() - 1);
    int yy = y;
    for (size_t i = 0; i < v.size(); i++) {
        Job& j = *v[i];
        bool a = (int)i == sel;
        if (j.st == Job::RUNNING && j.swarm) {
            draw_card(g, j, x, yy, w, now);
            if (a) g.frame(x, yy, w, 236, 2, ACC);
            yy += 248;
        } else {
            if (yy + 64 > Gfx::H - BOT_H) break;
            g.rrect(x, yy, w, 58, 10, a ? CARD2 : CARD);
            if (a) g.frame(x, yy, w, 58, 2, ACC);
            g.text(x + 14, yy + 6, g.fit(j.meta.name, w - 300, F_BODY), TXT, F_BODY);
            std::string st; uint32_t sc = DIM;
            switch (j.st) {
            case Job::QUEUED: st = "в очереди"; sc = ACC; break;
            case Job::PAUSED: st = "приостановлено"; sc = WARN; break;
            case Job::ERROR: st = "ошибка"; sc = ERRC; break;
            default: break;
            }
            g.text_right(x + w - 14, yy + 6, st, sc, F_BODY);
            std::string sub = "Файлов: " + std::to_string(j.files_done) + " из " + std::to_string(j.meta.files.size()) + "  ·  " + human_size((double)j.meta.total);
            if (j.st == Job::ERROR) sub = j.err;
            g.text(x + 14, yy + 34, g.fit(sub, w - 28, F_SMALL), j.st == Job::ERROR ? ERRC : DIM, F_SMALL);
            yy += 64;
        }
    }
}

void App::draw_installed(Gfx& g) {
    int x = CX, y = TOP_H + 14, w = Gfx::W - x - 16;
    auto v = const_cast<App*>(this)->done_entries();
    g.text(x, y, "Скачано и установлено через archive_nintendo: " + std::to_string(v.size()), DIM, F_SMALL);
    y += 28;
    if (v.empty()) {
        g.rrect(x, y, w, 100, 12, CARD);
        g.text(x + 24, y + 28, "Пока ничего нет — готовые загрузки появятся здесь.", DIM, F_BODY);
        return;
    }
    int rh = 70, vis = rows_visible(Gfx::H - BOT_H - y - 8, rh), sel = std::min(sel_[0], (int)v.size() - 1);
    int first = std::max(0, std::min(sel - vis / 2, (int)v.size() - vis));
    for (int i = 0; i < vis && first + i < (int)v.size(); i++) {
        LibEntry& e = *v[first + i];
        int yy = y + i * rh;
        bool a = first + i == sel;
        g.rrect(x, yy, w, rh - 6, 10, a ? CARD2 : CARD);
        if (a) g.frame(x, yy, w, rh - 6, 2, ACC);
        g.text(x + 14, yy + 6, g.fit("✓ " + e.name, w - 220, F_BODY), TXT, F_BODY);
        g.text_right(x + w - 14, yy + 6, human_size((double)e.total), TXT, F_BODY);
        std::string sub = pf_->date_str(e.when);
        if (!e.note.empty()) sub += "  ·  " + e.note;
        g.text(x + 14, yy + 36, g.fit(sub, w - 28, F_SMALL), DIM, F_SMALL);
    }
}

void App::draw_bottom(Gfx& g, uint64_t now) {
    int y = Gfx::H - BOT_H;
    g.rect(0, y, Gfx::W, BOT_H, PANEL);
    std::string h;
    if (tab_ == 2) h = "L/R вкладки   ↑↓ выбор   A скачать   X обновить   Y установка NSP   − куда ставить   + выход";
    else if (tab_ == 1) h = "L/R вкладки   ↑↓ выбор   A пауза/продолжить   X отменить   Y установка NSP   + выход";
    else h = "L/R вкладки   ↑↓ выбор   X убрать из списка   + выход";
    g.text(20, y + 12, g.fit(h, Gfx::W - 40, F_SMALL), DIM, F_SMALL);
    if (now < toast_until_ && !toast_.empty()) {
        int tw = std::min(Gfx::W - 300, g.text_width(toast_, F_BODY) + 40);
        int tx = SIDE_W + (Gfx::W - SIDE_W - tw) / 2;
        g.rrect(tx, y - 54, tw, 42, 12, C(60, 70, 100));
        g.text(tx + 20, y - 46, g.fit(toast_, tw - 40, F_BODY), TXT, F_BODY);
    }
}

void App::draw(Gfx& g, uint64_t now) {
    last_draw_ = now; dirty_ = false;
    if (screen_off_) { g.clear(C(0, 0, 0)); return; }
    g.clear(BG);
    draw_side(g);
    if (tab_ == 2) draw_torrents(g, now);
    else if (tab_ == 1) draw_downloads(g, now);
    else draw_installed(g);
    draw_top(g);
    draw_bottom(g, now);
}
