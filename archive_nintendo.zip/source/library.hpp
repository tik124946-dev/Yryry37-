#pragma once
#include <stdint.h>
#include <string>
#include <vector>

// Список скачанного/установленного: sdmc:/archive_nintendo/library.txt (TSV)
struct LibEntry {
    std::string hash;        // info_hash (hex)
    std::string name;
    uint64_t total = 0;
    uint32_t files_done = 0, files_total = 0;
    int status = 0;          // 0 в процессе, 1 готово, 2 ошибка
    int64_t when = 0;
    std::string note;
    std::string tpath;       // путь к .torrent (для продолжения)
};

struct Library {
    std::vector<LibEntry> items;
    std::string path;
    bool load(const std::string& p);
    bool save();
    LibEntry* find(const std::string& hash);
    void upsert(const LibEntry& e);
    void remove(const std::string& hash);
};
