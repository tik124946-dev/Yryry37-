#pragma once
#include "sink.hpp"
#include "meta.hpp"
#include "platform.hpp"
#include <stdio.h>
#include <string>
#include <vector>

// Куда класть файл из торрента. Возвращает путь на SD; пустая строка — файл не копировать на SD (NSP → установка).
// is_switch — файл относится к структуре switch/atmosphere/config (порты, хомбрю, моды).
std::string route_dest(const std::string& root, const std::string& tname, bool multi, const std::string& rel,
                       bool has_nro, bool* is_switch = nullptr);

// Человекочитаемое назначение для предпросмотра: «установка NSP», «switch/…», «downloads/…».
std::string route_label(const Meta& m, size_t idx, bool install_nsp);

class Router : public Sink {
public:
    Router(Platform* pf, bool install_nsp, int storage) : pf_(pf), install_(install_nsp), storage_(storage) {}
    ~Router() override { abort(); }
    bool file_begin(const Meta& m, size_t idx) override;
    bool file_data(const uint8_t* p, size_t n) override;
    bool file_end() override;
    std::string error() override { return err_; }
    void abort();

    const std::string& current_name() const { return cur_name_; }
    bool installing() const { return inst_ != nullptr; }
    uint64_t inst_bytes() const { return inst_bytes_; }
    uint64_t inst_total() const { return inst_total_; }
    int n_installed() const { return n_installed_; }
    int n_routed() const { return n_routed_; }
    const std::string& last_info() const { return last_info_; }
    std::string summary() const;

private:
    Platform* pf_;
    bool install_;
    int storage_;
    std::string err_, cur_name_, last_info_, cur_dest_;
    FILE* fp_ = nullptr;
    Installer* inst_ = nullptr;
    uint64_t inst_bytes_ = 0, inst_total_ = 0, wrote_ = 0;
    int n_installed_ = 0, n_routed_ = 0, n_plain_ = 0, n_zips_ = 0;
    std::string zip_err_;
    bool cur_switch_ = false;
};
