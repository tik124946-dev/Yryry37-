#include "gfx.hpp"
#include "font_data.h"
#include <stdio.h>
#include <string.h>
#include <algorithm>

static const FFont* font_of(FontId f) {
    switch (f) {
    case F_SMALL: return &f_small_font;
    case F_TITLE: return &f_title_font;
    case F_BIG: return &f_big_font;
    default: return &f_body_font;
    }
}

static const FGlyph* find_glyph(const FFont* ft, uint32_t cp) {
    int lo = 0, hi = ft->n - 1;
    while (lo <= hi) {
        int mid = (lo + hi) / 2;
        if (ft->g[mid].cp == cp) return &ft->g[mid];
        if (ft->g[mid].cp < cp) lo = mid + 1; else hi = mid - 1;
    }
    if (cp != '?') return find_glyph(ft, '?');
    return nullptr;
}

static uint32_t next_cp(const std::string& s, size_t& i) {
    unsigned char c = (unsigned char)s[i++];
    if (c < 0x80) return c;
    int n = (c >= 0xF0) ? 3 : (c >= 0xE0) ? 2 : (c >= 0xC0) ? 1 : 0;
    uint32_t cp = n == 3 ? (c & 7) : n == 2 ? (c & 15) : n == 1 ? (c & 31) : c;
    while (n-- > 0 && i < s.size() && ((unsigned char)s[i] & 0xC0) == 0x80) cp = (cp << 6) | ((unsigned char)s[i++] & 0x3F);
    return cp;
}

void Gfx::clear(uint32_t c) { std::fill(px.begin(), px.end(), c); }

void Gfx::rect(int x, int y, int w, int h, uint32_t c) {
    int x0 = std::max(0, x), y0 = std::max(0, y), x1 = std::min(W, x + w), y1 = std::min(H, y + h);
    if (x1 <= x0) return;
    uint32_t a = c >> 24;
    for (int yy = y0; yy < y1; yy++) {
        uint32_t* row = &px[(size_t)yy * W];
        if (a == 255) { for (int xx = x0; xx < x1; xx++) row[xx] = c; }
        else for (int xx = x0; xx < x1; xx++) {
            uint32_t d = row[xx];
            uint32_t r = ((c & 255) * a + (d & 255) * (255 - a)) / 255;
            uint32_t g = (((c >> 8) & 255) * a + ((d >> 8) & 255) * (255 - a)) / 255;
            uint32_t b = (((c >> 16) & 255) * a + ((d >> 16) & 255) * (255 - a)) / 255;
            row[xx] = r | g << 8 | b << 16 | 0xFF000000u;
        }
    }
}

void Gfx::rrect(int x, int y, int w, int h, int r, uint32_t c) {
    r = std::min(r, std::min(w, h) / 2);
    if (r <= 0) { rect(x, y, w, h, c); return; }
    rect(x + r, y, w - 2 * r, h, c);
    rect(x, y + r, r, h - 2 * r, c);
    rect(x + w - r, y + r, r, h - 2 * r, c);
    for (int i = 0; i < r; i++) {
        // ширина вставки на строке i от края (четверть окружности)
        int dy = r - i;
        int dx = r - (int)(__builtin_sqrt((double)(r * r - dy * dy + 0.5)));
        rect(x + dx, y + i, r - dx, 1, c);
        rect(x + w - r, y + i, r - dx, 1, c);
        rect(x + dx, y + h - 1 - i, r - dx, 1, c);
        rect(x + w - r, y + h - 1 - i, r - dx, 1, c);
    }
}

void Gfx::frame(int x, int y, int w, int h, int t, uint32_t c) {
    rect(x, y, w, t, c); rect(x, y + h - t, w, t, c);
    rect(x, y, t, h, c); rect(x + w - t, y, t, h, c);
}

int Gfx::line_height(FontId f) { return font_of(f)->height; }

int Gfx::text_width(const std::string& s, FontId f) {
    const FFont* ft = font_of(f);
    int w = 0;
    for (size_t i = 0; i < s.size();) {
        const FGlyph* g = find_glyph(ft, next_cp(s, i));
        if (g) w += g->adv;
    }
    return w;
}

void Gfx::text(int x, int y, const std::string& s, uint32_t c, FontId f) {
    const FFont* ft = font_of(f);
    int base = y + ft->ascent;
    uint32_t cr = c & 255, cg = (c >> 8) & 255, cb = (c >> 16) & 255, ca = c >> 24;
    for (size_t i = 0; i < s.size();) {
        const FGlyph* g = find_glyph(ft, next_cp(s, i));
        if (!g) continue;
        const uint8_t* bm = ft->bmp + g->off;
        for (int gy = 0; gy < g->h; gy++) {
            int py = base + g->by + gy;
            if (py < 0 || py >= H) continue;
            for (int gx = 0; gx < g->w; gx++) {
                int pxx = x + g->bx + gx;
                if (pxx < 0 || pxx >= W) continue;
                uint32_t a = bm[gy * g->w + gx] * ca / 255;
                if (!a) continue;
                uint32_t& d = px[(size_t)py * W + pxx];
                uint32_t r = (cr * a + (d & 255) * (255 - a)) / 255;
                uint32_t gg = (cg * a + ((d >> 8) & 255) * (255 - a)) / 255;
                uint32_t b = (cb * a + ((d >> 16) & 255) * (255 - a)) / 255;
                d = r | gg << 8 | b << 16 | 0xFF000000u;
            }
        }
        x += g->adv;
    }
}

std::string Gfx::fit(const std::string& s, int maxw, FontId f) {
    if (text_width(s, f) <= maxw) return s;
    std::string cut;
    size_t i = 0;
    std::string dots = "…";
    int dw = text_width(dots, f);
    while (i < s.size()) {
        size_t st = i;
        next_cp(s, i);
        std::string t = cut + s.substr(st, i - st);
        if (text_width(t, f) + dw > maxw) break;
        cut = t;
    }
    return cut + dots;
}

bool Gfx::save_ppm(const std::string& path) const {
    FILE* fp = fopen(path.c_str(), "wb");
    if (!fp) return false;
    fprintf(fp, "P6\n%d %d\n255\n", W, H);
    std::vector<uint8_t> row(W * 3);
    for (int y = 0; y < H; y++) {
        for (int x = 0; x < W; x++) {
            uint32_t p = px[(size_t)y * W + x];
            row[x * 3] = p & 255; row[x * 3 + 1] = (p >> 8) & 255; row[x * 3 + 2] = (p >> 16) & 255;
        }
        fwrite(row.data(), 1, row.size(), fp);
    }
    fclose(fp);
    return true;
}
